package ac.liv.csc.comp201.model;

public interface IDisplay {
	public void setTextString(String text);	// set's text on the display

}
